package dotest.module.coreassemblys.ui;

import core.object.DoUIModule;

public class DoTestSampleModel extends DoUIModule {

	public DoTestSampleModel() throws Exception {
		super();
	}

	@Override
	public void onInit() throws Exception {
		super.onInit();
		
	}
}
