package doext.define;

import core.object.DoMultitonModule;

public abstract class do_Bluetooth_MAbstract extends DoMultitonModule{

	protected do_Bluetooth_MAbstract() throws Exception {
		super();
	}
	
	/**
	 * 初始化
	 */
	@Override
	public void onInit() throws Exception{
        super.onInit();
        //注册属性
	}
}