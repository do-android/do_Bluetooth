package doext.define;


/**
 * 声明自定义扩展组件方法
 */
public interface do_Bluetooth_IMethod {
}